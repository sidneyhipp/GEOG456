// This was originally a geoJSON
// I added the words 'var waypoints = '  
// and change the .geoJSON file name extension to .js
// Now the geoJSON should behave like a js variable
var waypoints = {
"type": "FeatureCollection",
"name": "waypoints",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "y": 35.909959, "x": -79.050328, "z": 146.5, "t": "2024-01-19T16:29:19", "note": "hello I am waypoint 0" }, "geometry": { "type": "Point", "coordinates": [ -79.050328, 35.909959 ] } },
{ "type": "Feature", "properties": { "y": 35.909978, "x": -79.050279, "z": 145.5, "t": "2024-01-19T16:29:23", "note": "hello I am waypoint 1" }, "geometry": { "type": "Point", "coordinates": [ -79.050279, 35.909978 ] } },
{ "type": "Feature", "properties": { "y": 35.909964, "x": -79.050214, "z": 144.0, "t": "2024-01-19T16:29:26", "note": "hello I am waypoint 2" }, "geometry": { "type": "Point", "coordinates": [ -79.050214, 35.909964 ] } },
{ "type": "Feature", "properties": { "y": 35.909962, "x": -79.05011, "z": 144.0, "t": "2024-01-19T16:29:32", "note": "hello I am waypoint 3" }, "geometry": { "type": "Point", "coordinates": [ -79.05011, 35.909962 ] } },
{ "type": "Feature", "properties": { "y": 35.909978, "x": -79.05001, "z": 143.0, "t": "2024-01-19T16:29:38", "note": "hello I am waypoint 4" }, "geometry": { "type": "Point", "coordinates": [ -79.05001, 35.909978 ] } },
{ "type": "Feature", "properties": { "y": 35.910008, "x": -79.04993, "z": 144.0, "t": "2024-01-19T16:29:42", "note": "hello I am waypoint 5" }, "geometry": { "type": "Point", "coordinates": [ -79.04993, 35.910008 ] } },
{ "type": "Feature", "properties": { "y": 35.910013, "x": -79.049809, "z": 143.0, "t": "2024-01-19T16:29:50", "note": "hello I am waypoint 6" }, "geometry": { "type": "Point", "coordinates": [ -79.049809, 35.910013 ] } },
{ "type": "Feature", "properties": { "y": 35.910119, "x": -79.049639, "z": 142.0, "t": "2024-01-19T16:30:07", "note": "hello I am waypoint 7" }, "geometry": { "type": "Point", "coordinates": [ -79.049639, 35.910119 ] } },
{ "type": "Feature", "properties": { "y": 35.910185, "x": -79.049685, "z": 142.0, "t": "2024-01-19T16:30:13", "note": "hello I am waypoint 8" }, "geometry": { "type": "Point", "coordinates": [ -79.049685, 35.910185 ] } },
{ "type": "Feature", "properties": { "y": 35.910348, "x": -79.049859, "z": 144.0, "t": "2024-01-19T16:30:31", "note": "hello I am waypoint 9" }, "geometry": { "type": "Point", "coordinates": [ -79.049859, 35.910348 ] } },
{ "type": "Feature", "properties": { "y": 35.910425, "x": -79.049957, "z": 144.0, "t": "2024-01-19T16:30:39", "note": "hello I am waypoint 10" }, "geometry": { "type": "Point", "coordinates": [ -79.049957, 35.910425 ] } },
{ "type": "Feature", "properties": { "y": 35.910519, "x": -79.050005, "z": 146.0, "t": "2024-01-19T16:30:49", "note": "hello I am waypoint 11" }, "geometry": { "type": "Point", "coordinates": [ -79.050005, 35.910519 ] } },
{ "type": "Feature", "properties": { "y": 35.910594, "x": -79.050006, "z": 146.0, "t": "2024-01-19T16:30:57", "note": "hello I am waypoint 12" }, "geometry": { "type": "Point", "coordinates": [ -79.050006, 35.910594 ] } },
{ "type": "Feature", "properties": { "y": 35.910645, "x": -79.05003, "z": 148.1, "t": "2024-01-19T16:31:03", "note": "hello I am waypoint 13" }, "geometry": { "type": "Point", "coordinates": [ -79.05003, 35.910645 ] } },
{ "type": "Feature", "properties": { "y": 35.91072, "x": -79.050089, "z": 144.0, "t": "2024-01-19T16:31:11", "note": "hello I am waypoint 14" }, "geometry": { "type": "Point", "coordinates": [ -79.050089, 35.91072 ] } },
{ "type": "Feature", "properties": { "y": 35.910801, "x": -79.050171, "z": 148.0, "t": "2024-01-19T16:31:21", "note": "hello I am waypoint 15" }, "geometry": { "type": "Point", "coordinates": [ -79.050171, 35.910801 ] } },
{ "type": "Feature", "properties": { "y": 35.910864, "x": -79.050205, "z": 147.0, "t": "2024-01-19T16:31:28", "note": "hello I am waypoint 16" }, "geometry": { "type": "Point", "coordinates": [ -79.050205, 35.910864 ] } },
{ "type": "Feature", "properties": { "y": 35.911032, "x": -79.05023, "z": 148.0, "t": "2024-01-19T16:31:44", "note": "hello I am waypoint 17" }, "geometry": { "type": "Point", "coordinates": [ -79.05023, 35.911032 ] } },
{ "type": "Feature", "properties": { "y": 35.911071, "x": -79.050281, "z": 147.0, "t": "2024-01-19T16:31:54", "note": "hello I am waypoint 18" }, "geometry": { "type": "Point", "coordinates": [ -79.050281, 35.911071 ] } },
{ "type": "Feature", "properties": { "y": 35.911002, "x": -79.050381, "z": 148.8, "t": "2024-01-19T16:32:15", "note": "hello I am waypoint 19" }, "geometry": { "type": "Point", "coordinates": [ -79.050381, 35.911002 ] } }
]
}
